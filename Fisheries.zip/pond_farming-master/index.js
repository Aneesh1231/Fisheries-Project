const con = require("./connection");
const express = require ("express");
const app = express();
const bodyParser = require('body-parser');
const jwt = require('jsonwebtoken');
const cookieparser = require('cookie-parser')
const port = 7000

// const encoder = bodyParser.urlencoded();
app.use(cookieparser())
app.use("/assets",express.static("assets"));
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended:true}));

app.get('/',function(req,res) {
  res.sendFile(__dirname+'/public/starthome.html');
});
app.get('/signup',function(req,res) {
    res.sendFile(__dirname+'/public/signup.html');
 });
app.get('/login',function(req,res) {
  res.sendFile(__dirname+'/public/login.html');
});
app.get('/Adminhome',function(req,res) {
  res.sendFile(__dirname+'/public/admin.html');
});
app.get('/Ownerhome',function(req,res) {
  res.sendFile(__dirname+'/public/ownerhome.html');
});
app.get('/breeder',function(req,res) {
  res.sendFile(__dirname+'/public/breeadmin.html');
});
app.get('/dealer',function(req,res) {
  res.sendFile(__dirname+'/public/deeadmin.html');
});
app.get('/species',function(req,res) {
  res.sendFile(__dirname+'/public/species.html');
});
app.get('/pond',function(req,res) {
  res.sendFile(__dirname+'/public/pond.html');
});
app.get('/contact',function(req,res) {
  res.sendFile(__dirname+'/public/contact.html');
});
app.get('/Breederhome',function(req,res) {
  res.sendFile(__dirname+'/public/breederhome.html');
});
app.get('/Dealerhome',function(req,res) {
  res.sendFile(__dirname+'/public/dealerhome.html');
});
app.get('/owner',function(req,res) {
  res.sendFile(__dirname+'/public/ownadmin.html');
});
app.get('/bsview',function(req,res) {
  res.sendFile(__dirname+'/public/sview.html');
});
app.get('/bsbview',function(req,res) {
  res.sendFile(__dirname+'/public/sview2.html');
});
app.get('/pview',function(req,res) {
  res.sendFile(__dirname+'/public/pview.html');
});
app.get('/breedview',function(req,res) {
  res.sendFile(__dirname+'/public/Bview.html');
});
app.get('/dealview',function(req,res) {
  res.sendFile(__dirname+'/public/Dview.html');
});
app.get('/sview3',function(req,res) {
  res.sendFile(__dirname+'/public/sview3.html');
});
app.get('/addspecies',function(req,res) {
  res.sendFile(__dirname+'/public/addspecies.html');
});
app.get('/addspecies1',function(req,res) {
  res.sendFile(__dirname+'/public/addspecies1.html');
});
app.get('/sell',function(req,res) {
  res.sendFile(__dirname+'/public/sells.html');
});
app.get('/buy',function(req,res) {
  res.sendFile(__dirname+'/public/buys.html');
});
app.get('/dealerdeals',function(req,res) {
  res.sendFile(__dirname+'/public/dealerdeal.html');
});
app.get('/contactview',function(req,res) {
  res.sendFile(__dirname+'/public/contactview.html');
});
app.get('/ownadd',function(req,res) {
  res.sendFile(__dirname+'/public/ownadd.html');
});
app.get('/breederdeals',function(req,res) {
  res.sendFile(__dirname+'/public/breederdeal.html');
});

//code snippet for registration module
app.post('/signup',function(req,res){
   
    var Name = req.body.name;
    var email = req.body.email;
    var password = req.body.password;
    var role = req.body.role;

    var sql = "INSERT INTO info_db(name,email,password,designation) VALUES('"+Name+"','"+email+"','"+password+"','"+role+"')";
  con.query(sql,function(error){
    if(error) throw error;
    res.redirect('../login');
  })
});

//code snippet for login module
 app.post("/login",function(req,res){
   const Email =req.body.email;
   var Password=req.body.password;
   console.log(Email,Password)
   con.query("SELECT * FROM `info_db` WHERE `email` = ? AND `password` = ?" ,[Email,Password],function(error,results,fields){
     console.log(results.length)
    if(results.length > 0 ){
       const token = jwt.sign({email: Email, password:Password},"AjayHacker",{ expiresIn : "1d"});
       console.log(token)
       const cookieOptions = {
          expires : new Date(Date.now() + 1*24*60*60*1000),
          httpOnly : false 
       }
       res.cookie("Registered",token,cookieOptions);
       res.redirect('../' + results[0].designation + "home" );

     }
     else
     {
  
       res.redirect('../login?status=1');
     }
    
   });
 });

 app.post('/contact',function(req,res){
  var Name = req.body.Name;
  var Email = req.body.Email;
  var Message = req.body.Message;
  console.log(req.body)
  var mpb = "INSERT INTO queries(Name,Email,Message) VALUES('"+Name+"','"+Email+"','"+Message+"')";
con.query(mpb,function(error){
  if(error) throw error;
  res.redirect('../contact');
})
});
app.get('/getdetails8',(req,res)=>{
  con.query("SELECT * FROM queries",(err,results)=>{
    if(err) console.log(err)
    else{
      console.log(results[0])
      res.send(results)
    }
  })
})
 app.post('/Ownerhome',function(req,res){
  var O_email = req.body.O_email;
  var O_name = req.body.O_name;
  var O_phone = req.body.O_phone;
  var O_address = req.body.O_address;

  console.log(req.body)
  var mpb = "INSERT INTO owner(O_email,O_name,O_phone,O_address) VALUES('"+O_email+"','"+O_name+"','"+O_phone+"','"+O_address+"')";
con.query(mpb,function(error){
  if(error) res.redirect('../Ownerhome?failed=1')
  else
  res.redirect('../Ownerhome');
})
});
app.post('/Ownerhome/species',function(req,res){
  var O_email = req.body.O_email;
  var S_id = req.body.S_id;
  var P_id = req.body.P_id;
  console.log(req.body)
  var dfg = "INSERT INTO owner_add (O_email,S_id,P_id) VALUES('"+O_email+"','"+S_id+"','"+P_id+"')";
con.query(dfg,function(error){
  if(error) res.redirect('../Ownerhome?failed=1')
  else
  res.redirect('../Ownerhome');
})
}); 
  
app.get('/getdetails',(req,res)=>{
  con.query("SELECT * FROM owner O,owner_add OA WHERE O.O_email=OA.O_email",(err,results)=>{
    if(err) console.log(err)
    else{
      console.log(results[0])
      res.send(results)
    }
  })
})

//code snippet of view module
app.get('/getdetailsa',(req,res)=>{
  const token = jwt.verify(req.cookies.Registered,'AjayHacker');
  const Email = token.email;
  console.log(Email)
  con.query("SELECT * FROM owner O,owner_add OA WHERE O.O_email=OA.O_email AND O.O_email=?",[Email],(err,results)=>{
    if(err) console.log(err)
    else{
      console.log(results[0])
      res.send(results)
    }
  })
})

app.post('/species',function(req,res){
  var S_id = req.body.S_id;
  var S_name = req.body.S_name;
  var S_food = req.body.S_food;
  var S_size = req.body.S_size;
  var S_grade = req.body.S_grade;
  console.log(req.body)
  var dfg = "INSERT INTO species(S_id,S_name,S_food,S_size,S_grade) VALUES('"+S_id+"','"+S_name+"','"+S_food+"','"+S_size+"','"+S_grade+"')";
con.query(dfg,function(error){
  if(error) res.redirect('../species?failed=1')
  else
  res.redirect('../species');
})
});
app.get('/getdetails1',(req,res)=>{
  con.query("SELECT * FROM species",(err,results)=>{
    if(err) console.log(err)
    else{
      console.log(results[0])
      res.send(results)
    }
  })
})
 
app.post('/pond',function(req,res){
  var P_id = req.body.P_id;
  var P_type= req.body.P_type;
  var P_temp = req.body.P_temp;
  var P_species = req.body.P_species;
  console.log(req.body)
  var dfg = "INSERT INTO pond(P_id,P_type,P_temp,P_species) VALUES('"+P_id+"','"+P_type+"','"+P_temp+"','"+P_species+"')";
con.query(dfg,function(error){
  if(error) res.redirect('../pond?failed=1')
  else
  res.redirect('../pond');
})
}); 
 
app.get('/getdetails2',(req,res)=>{
  con.query("SELECT * FROM pond",(err,results)=>{
    if(err) console.log(err)
    else{
      console.log(results)
      res.send(results)
    }
  })
})

  
app.post('/Breederhome',function(req,res){
  var B_email = req.body.B_email;
  var B_name= req.body.B_name;
  var B_phone = req.body.B_phone;
  var B_address = req.body.B_address;
  var B_district = req.body.B_district;
  console.log(req.body)
  var dfg = "INSERT INTO breeder(B_email,B_name,B_phone,B_address,B_district) VALUES('"+B_email+"','"+B_name+"','"+B_phone+"','"+B_address+"','"+B_district+"')";
con.query(dfg,function(error){
  if(error) res.redirect('../Breederhome?failed=1')
  else
  res.redirect('../Breederhome');
})
}); 
 
app.post('/Breederhome/species',function(req,res){
  var B_email = req.body.B_email;
  var S_id = req.body.S_id;
  console.log(req.body)
  var dfg = "INSERT INTO breeder_species (B_email,S_id) VALUES('"+B_email+"','"+S_id+"')";
con.query(dfg,function(error){
  if(error) res.redirect('../Breederhome?failed=1')
  else
  res.redirect('../Breederhome');
})
}); 
  
app.get('/getdetails3',(req,res)=>{
  con.query("SELECT * FROM breeder B,breeder_species bs WHERE B.B_email=bs.B_email",(err,results)=>{
    if(err) console.log(err)
    else{
      console.log(results[0])
      res.send(results)
    }
  })
})
app.get('/getdetails3a',(req,res)=>{
  const token = jwt.verify(req.cookies.Registered,'AjayHacker');
  const Email = token.email;
  console.log(Email)
  con.query("SELECT * FROM breeder B , breeder_species bs WHERE B.B_email=bs.B_email AND B.B_email =?",[Email],(err,results)=>{
    if(err) console.log(err)
    else{
      console.log(results[0])
      res.send(results)
    }
  })
})
   
  
app.post('/Dealerhome',function(req,res){
  var D_email = req.body.D_email;
  var D_name= req.body.D_name;
  var D_phone = req.body.D_phone;
  var D_address = req.body.D_address;

  console.log(req.body)
  var dfg = "INSERT INTO dealer(D_email,D_name,D_phone,D_address) VALUES('"+D_email+"','"+D_name+"','"+D_phone+"','"+D_address+"')";
con.query(dfg,function(error){
  if(error) res.redirect('../Dealerhome?failed=1')
  else
  res.redirect('../Dealerhome');
})
}); 
 
  

app.post('/Dealerhome/species',function(req,res){
  var D_email = req.body.D_email;
  var S_id = req.body.S_id;
  console.log(req.body)
  var dfg = "INSERT INTO dealer_species (D_email,S_id) VALUES('"+D_email+"','"+S_id+"')";
con.query(dfg,function(error){
  if(error) res.redirect('../Dealerhome?failed=1')
  else
  res.redirect('../Dealerhome');
})
}); 
  
app.get('/getdetails4',(req,res)=>{
  con.query("SELECT * FROM dealer D,dealer_species ds WHERE D.D_email=ds.D_email",(err,results)=>{
    if(err) console.log(err)
    else{
      console.log(results[0])
      res.send(results)
    }
  })
})
app.get('/getdetails4a',(req,res)=>{
 const token = jwt.verify(req.cookies.Registered,'AjayHacker');
  const Email = token.email;
  console.log(Email)
  con.query("SELECT * FROM dealer D , dealer_species ds WHERE D.D_email=ds.D_email AND D.D_email =?",[Email],(err,results)=>{
    if(err) console.log(err)
    else{
      console.log(results)
      res.send(results)
    }
  })
})

app.post('/buy',function(req,res){
  var O_email = req.body.O_email;
  var B_email = req.body.B_email;
  var S_id = req.body.S_id;
  var S_quantity = req.body.S_quantity;
  var requirements = req.body.requirements;
  console.log(req.body)

  var mpb = "INSERT INTO buy(O_email,B_email,S_id,S_quantity,requirements) VALUES('"+O_email+"','"+B_email+"','"+S_id+"','"+S_quantity+"','"+requirements+"')";
con.query(mpb,function(error){
  if(error) res.redirect('../buy?failed=1')
  else
  res.redirect('../buy');
})
});
app.get('/getdetails5',(req,res)=>{
  const token = jwt.verify(req.cookies.Registered,'AjayHacker');
  const Email = token.email;
  console.log(Email)
  con.query("SELECT * FROM buy WHERE  B_email =?",[Email],(err,results)=>{
    if(err) console.log(err)
    else{
      console.log(results[0])
      res.send(results)
    }
  })
})
app.post('/sell',function(req,res){
  var O_email = req.body.O_email;
  var D_email = req.body.D_email;
  var S_id = req.body.S_id;
  var S_quantity = req.body.S_quantity;
  var S_rate = req.body.S_rate;
  console.log(req.body)
  var mpb = "INSERT INTO sell(O_email,D_email,S_id,S_quantity,S_rate) VALUES('"+O_email+"','"+D_email+"','"+S_id+"','"+S_quantity+"','"+S_rate+"')";
con.query(mpb,function(error){
  if(error) res.redirect('../sell?failed=1')
  else
  res.redirect('../sell');
})
});
app.get('/getdetails6',(req,res)=>{
  const token = jwt.verify(req.cookies.Registered,'AjayHacker');
  const Email = token.email;
  console.log(Email)
  con.query("SELECT O_email,S_id,S_quantity,S_rate,S_quantity*S_rate AS total FROM sell WHERE  D_email =?",[Email],(err,results)=>{
    if(err) console.log(err)
    else{
      console.log(results[0])
      res.send(results)
    }
  })
})
//code snippet for delete module
app.get('/delete',(req,res)=>{
    const B_email = req.query.B_email
    console.log(B_email)
    con.query("DELETE FROM breeder WHERE B_email =?",[B_email],(err,results)=>{
      if(err){
        console.log(err)
        res.status(404).send("Error Occured")
      }
      else{
        res.redirect('/breeder?message=Deleted_Succesfully')
      }
    })
})
app.get('/delete1',(req,res)=>{
  const D_email = req.query.D_email
  console.log(D_email)
  con.query("DELETE FROM dealer WHERE D_email =?",[D_email],(err,results)=>{
    if(err){
      console.log(err)
      res.status(404).send("Error Occured")
    }
    else{
      res.redirect('/dealer?message=Deleted_Succesfully')
    }
  })
})
app.get('/delete2',(req,res)=>{
  const O_email = req.query.O_email
  console.log(O_email)
  con.query("DELETE FROM owner WHERE O_email =?",[O_email],(err,results)=>{
    if(err){
      console.log(err)
      res.status(404).send("Error Occured")
    }
    else{
      res.redirect('/owner?message=Deleted_Succesfully')
    }
  })
})
app.get('/delete3',(req,res)=>{
  const P_id = req.query.P_id
  console.log(P_id)
  con.query("DELETE FROM pond WHERE P_id =?",[P_id],(err,results)=>{
    if(err){
      console.log(err)
      res.status(404).send("Error Occured")
    }
    else{
      res.redirect('/pond?message=Deleted_Succesfully')
    }
  })
})
app.get('/delete4',(req,res)=>{
  const S_id = req.query.S_id
  console.log(S_id)
  con.query("DELETE FROM species WHERE S_id =?",[S_id],(err,results)=>{
    if(err){
      console.log(err)
      res.status(404).send("Error Occured")
    }
    else{
      res.redirect('/species?message=Deleted_Succesfully')
    }
  })
})


   /*app.post('/Update',(req,res)=>{
  const {B_email,B_phone,B_address,B_district,S_id} = req.body
  console.log(B_email)
  console.log(B_phone)
  console.log(B_address)
  console.log(B_district)
  console.log(S_id)
  con.query("UPDATE breeder SET B_phone =?,B_address =?, B_district =? S_id=? WHERE B_email =?",[B_phone,B_address,B_district,S_id,B_email],(err,result)=>{
    if(err){
      console.log(err)
      res.status(404).send("Error occured")
    }
    else{
      res.redirect('/breeder?message=Updated_Succesfully')
    }
  })
})
app.post('/Update1',(req,res)=>{
  const {D_email,D_phone,D_address,S_id} = req.body
  console.log(D_email)
  console.log(D_phone)
  console.log(D_address)
  console.log(S_id)
  con.query("UPDATE dealer SET D_phone =?,D_address =?, S_id =? WHERE D_email =?",[D_phone,D_address,S_id,D_email],(err,result)=>{
    if(err){
      console.log(err)
      res.status(404).send("Error occured")
    }
    else{
      res.redirect('/dealer?message=Updated_Succesfully')
    }
  })
})
app.post('/Update2',(req,res)=>{
  const {O_email,O_phone,O_address,S_id,P_id} = req.body
  console.log(O_email)
  console.log(O_phone)
  console.log(O_address)
  console.log(S_id)
  console.log(P_id)
  con.query("UPDATE owner SET O_phone =?,O_address =?, S_id =? P_id =? WHERE O_email =?",[O_phone,O_address,S_id,P_id,O_email],(err,result)=>{
    if(err){
      console.log(err)
      res.status(404).send("Error occured")
    }
    else{
      res.redirect('/owner?message=Updated_Succesfully')
    }
  })
})*/



app.get('/logout',(req,res)=>{
  res.clearCookie("Registered")
  res.redirect('/login')
})


app.listen(port,()=>{
  console.log(`Server Running on ${port}`);
});